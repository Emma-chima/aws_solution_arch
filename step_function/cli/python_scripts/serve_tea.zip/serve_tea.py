def lambda_handler(event, context):
    return {
        'status': 'success',
        'message': 'Tea is served. Enjoy!'
    }
