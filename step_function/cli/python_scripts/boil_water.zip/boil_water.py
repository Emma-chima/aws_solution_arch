def lambda_handler(event, context):
    return {
        'status': 'success',
        'message': 'Water boiled'
    }
