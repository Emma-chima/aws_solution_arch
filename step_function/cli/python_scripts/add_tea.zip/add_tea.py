def lambda_handler(event, context):
    return {
        'status': 'success',
        'message': 'Tea leaves added to boiled water'
    }
